var searchData=
[
  ['匿名类',['匿名类',['../mainpage_8xcs.html#ac63a6111ce329d51f5e3fc9b09878a16',1,'mainpage.xcs']]],
  ['匿名类可以使用在其所在作用域内的对象',['匿名类可以使用在其所在作用域内的对象',['../mainpage_8xcs.html#a4cdda32e0dd2e9dd245cac271ad00665',1,'mainpage.xcs']]]
];
