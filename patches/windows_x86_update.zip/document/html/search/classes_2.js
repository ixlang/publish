var searchData=
[
  ['backgroundmode',['BackgroundMode',['../class_q_x_painter_1_1_background_mode.html',1,'QXPainter']]],
  ['base64',['Base64',['../class_base64.html',1,'']]],
  ['brushstyle',['BrushStyle',['../class_q_x_painter_1_1_brush_style.html',1,'QXPainter']]]
];
