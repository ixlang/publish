var searchData=
[
  ['bind',['bind',['../class_dgram_socket.html#ace53b11f2bc9ebf267032126d7bb09ea',1,'DgramSocket.bind()'],['../class_stream_socket.html#ace53b11f2bc9ebf267032126d7bb09ea',1,'StreamSocket.bind()']]]
];
