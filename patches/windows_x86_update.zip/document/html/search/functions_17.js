var searchData=
[
  ['y',['y',['../class_q_x_widget.html#ad2fbece2f53c8f17552a75843b4440b1',1,'QXWidget']]],
  ['yfromposition',['yFromPosition',['../class_q_x_sci.html#a1307467314b7e6ac75bedb48feb015a4',1,'QXSci']]]
];
