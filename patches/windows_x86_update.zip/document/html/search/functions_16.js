var searchData=
[
  ['x',['x',['../class_q_x_widget.html#a50ddd862d7f7c8f11d9c43c2c7a3bf37',1,'QXWidget']]],
  ['xdomnode',['XDomNode',['../class_x_dom_node.html#a2b215dc89373582049d55139ad783ec9',1,'XDomNode.XDomNode()'],['../class_x_dom_node.html#a0462d0a882474062f2a64a29f55c8e57',1,'XDomNode.XDomNode(String text)']]],
  ['xfromposition',['xFromPosition',['../class_q_x_sci.html#a5bd0e74eaf55ead0e54480170e1d128a',1,'QXSci']]]
];
