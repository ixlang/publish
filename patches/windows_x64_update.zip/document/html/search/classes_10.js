var searchData=
[
  ['renderhint',['RenderHint',['../class_q_x_painter_1_1_render_hint.html',1,'QXPainter']]],
  ['result',['Result',['../class_pattern_1_1_result.html',1,'Pattern']]],
  ['runnable',['Runnable',['../class_runnable.html',1,'']]]
];
