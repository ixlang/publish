var searchData=
[
  ['undo',['Undo',['../class_q_x_sci.html#a251dc16f349ac47b155a41f09fe28735',1,'QXSci']]],
  ['unsi',['Unsi',['../class_unsi.html#a25d971356d5ad43071f3435f358dcf53',1,'Unsi']]],
  ['update',['update',['../class_q_x_widget.html#ac5c54df7ed3b930268c8d7752c101725',1,'QXWidget']]],
  ['upper',['upper',['../class_string.html#a8d2ff59fc6acb92a53e77945e8626260',1,'String']]]
];
