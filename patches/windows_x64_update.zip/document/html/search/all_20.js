var searchData=
[
  ['变量名',['变量名',['../mainpage_8xcs.html#a145387344f7c804fc7ecdc2da5d00711',1,'mainpage.xcs']]],
  ['变量的数据类型：可以是基本类型',['变量的数据类型：可以是基本类型',['../mainpage_8xcs.html#af7a6444692dc443f9068a25ad076e62a',1,'mainpage.xcs']]]
];
