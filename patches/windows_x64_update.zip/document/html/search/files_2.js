var searchData=
[
  ['colorrole_2excsm',['ColorRole.xcsm',['../_color_role_8xcsm.html',1,'']]]
];
