var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz",
  1: "_abcdefhijlmnopqrstuvwx",
  2: "f",
  3: "abcdefhijlmpqstuvx",
  4: "abcdefghijlmnopqrstuvwxy",
  5: "_abcdefghiklmnopqrstuvwxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "全部",
  1: "结构体",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量"
};

